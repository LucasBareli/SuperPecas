package br.com.masterclass.superpecas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperPecasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperPecasApplication.class, args);
	}

}
